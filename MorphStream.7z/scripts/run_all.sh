#!/bin/bash

bash overview_runner.sh
bash sensitivity_runner.sh
bash model_runner.sh