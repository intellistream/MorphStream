package transaction.function;

public class AVG extends Function {
    public AVG(Integer delta) {
        this.delta_double = delta;
    }
}
