package transaction.function;

public class CNT extends Function {
    public CNT(int delta) {
        this.delta_int = delta;
    }
}
