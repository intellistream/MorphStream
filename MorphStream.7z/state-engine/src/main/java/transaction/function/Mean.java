package transaction.function;

public class Mean extends Function {
    public Mean(double[] new_value) {
        this.new_value = new_value;
    }

    public Mean(double[] new_value, Condition condition) {
        this.new_value = new_value;
    }
}
