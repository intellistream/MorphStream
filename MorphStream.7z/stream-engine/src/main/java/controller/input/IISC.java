package controller.input;

import java.io.Serializable;

/**
 * Created by shuhaozhang on 17/7/16.
 */
interface IISC extends Serializable {
    long serialVersionUID = 21L;
}
