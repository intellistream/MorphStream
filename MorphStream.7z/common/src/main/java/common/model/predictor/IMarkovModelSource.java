package common.model.predictor;

/**
 * @author maycon
 */
public interface IMarkovModelSource {
    String getModel(String key);
}
