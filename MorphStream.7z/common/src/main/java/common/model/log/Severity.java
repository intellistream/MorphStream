package common.model.log;

public enum Severity {
    LOW, MEDIUM, HIGH
}