package common.util.window;

/**
 * Author: Thilina
 * Date: 11/22/14
 */
public interface SlidingWindowEntry {
    long getTime();
}