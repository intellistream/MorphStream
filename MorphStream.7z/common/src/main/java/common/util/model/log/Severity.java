package common.util.model.log;

public enum Severity {
    LOW, MEDIUM, HIGH
}